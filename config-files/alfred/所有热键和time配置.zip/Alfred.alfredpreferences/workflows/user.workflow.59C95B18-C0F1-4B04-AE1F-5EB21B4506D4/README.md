# Alfred Workflows TimeStamp

此 workflows 可以转换时间与时间戳，同时显示与当前时间的距离
命令
time now 显示当前时间与时间戳
time 1488888888 时间戳转为时间
time 2017-03-07 20:14:48 时间转为时间戳，对时间格式要求不严谨

可以手动更新 TimeStamp更改时区
